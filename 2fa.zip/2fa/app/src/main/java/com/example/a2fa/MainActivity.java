package com.example.a2fa;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private EditText username, password, otp;
    private Button sendOtpButton, submitButton;
    private TextView otpDisplay;
    private String generatedOtp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        otp = findViewById(R.id.otp);
        sendOtpButton = findViewById(R.id.send_otp_button);
        submitButton = findViewById(R.id.submit_button);
        otpDisplay = findViewById(R.id.otp_display);

        sendOtpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String enteredUsername = username.getText().toString();
                String enteredPassword = password.getText().toString();

                if (enteredUsername.isEmpty() || enteredPassword.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter username and password", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Generate a random OTP and display it
                generatedOtp = generateOtp();
                otpDisplay.setText("Your OTP is: " + generatedOtp);
                otpDisplay.setVisibility(View.VISIBLE);

                otp.setVisibility(View.VISIBLE);
                submitButton.setVisibility(View.VISIBLE);
                Toast.makeText(MainActivity.this, "OTP has been generated and displayed", Toast.LENGTH_SHORT).show();
            }
        });

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String enteredOtpText = otp.getText().toString();

                if (enteredOtpText.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter the OTP", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (enteredOtpText.equals(generatedOtp)) {
                    Toast.makeText(MainActivity.this, "Authentication successful!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Incorrect OTP. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private String generateOtp() {
        Random random = new Random();
        int otp = random.nextInt(999999 - 100000) + 100000;  // Generate a 6-digit OTP
        return String.valueOf(otp);
    }
}
